title: TCP-粘包
author: Qiao
tags:
  - TCP
categories: []
date: 2023-09-21 15:45:00
---
# TCP 粘包

## 什么是TCP粘包

TCP粘包是, 当我们使用TCP协议时, 由于TCP`面向字节流`的特点, 无法区分消息的边界,所产生的问题

## TCP 的面向字节流是什么

众所周知, TCP是面向字节流的, UDP不是面向字节流的. 那么,什么是面向字节流呢?

当我们有多个信息,通过TCP传输时, 操作系统会自动帮我们分解和组合同一目的地的信息
例如: 当我们向主机B发送`Hello world`, `Ni hao`两条消息时
操作系统可能会这样帮我们生成TCP报文

![TCP.png](https://raw.githubusercontent.com/qiaofufu/draw_io/master/TCP-%E7%B2%98%E5%8C%85-01.png)

或者

![TCP-02.png](https://raw.githubusercontent.com/qiaofufu/draw_io/master/TCP-%E7%B2%98%E5%8C%85-02.png)

从上图中我们可以看到, 一个TCP报文并不表示一个完整的信息, 可能是部分信息, 也可能是多个信息, 而`UDP`呢?

![UDP-01.png](https://raw.githubusercontent.com/qiaofufu/draw_io/master/TCP-03.png)

`UDP` 报文表示一个完整信息, 所以该协议的使用者获取到报文可以直接使用, 不会有粘包问题

## TCP 粘包的解决办法

- 固定消息长度
  - 顾名思义, 我们可以固定所有消息的长度, 每次接受固定长度的数据即表示一个消息
- 特殊字符标识边界
  - 例如HTTP 使用 `\r\n`标识边界 
  - 注意: 对于标识的特殊字符需要转意
- 自定义消息结构
  - 例如TCP自身, 通过设置请求头,标识后续数据的长度,即可解决粘包问题