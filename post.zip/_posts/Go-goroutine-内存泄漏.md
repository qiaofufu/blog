title: Go goroutine 内存泄漏
author: Qiao
date: 2022-10-16 15:16:31
tags: [golang,goroutine,内存泄漏]
categories: [golang]
---
# Goroutine 内存泄漏

> 做某个笔试时,遇到的一道题,让你写一个goroutine导致内存泄漏, 

```go
package main

import (
	"net/http"
	"runtime/pprof"
)

func f(ch chan int) {
	<-ch // 这里一直得不到数据,会导致goroutine一直得不到释放
}

func main() {
	ch := make(chan int)
	for i := 0; i < 10; i++ {
		go f(ch)
	}
   // 到这里,我们已经没有操作`ch`channel了,按理来说应该回收goroutine
	http.HandleFunc("/", GetGoroutineNum)
	http.ListenAndServe(":3000", nil)
}

func GetGoroutineNum(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "text/plain")
	p := pprof.Lookup("goroutine")
	p.WriteTo(w, 1)
}

```

解决方案是用`context`来控制

```go
package main

import (
	"context"
	"net/http"
	"runtime/pprof"
)

func f(ctx context.Context, ch chan int) {
	select {
	case <-ch:
	case <-ctx.Done():
		return
	}
}

func main() {
	ctx, cancel := context.WithCancel(context.Background())
	ch := make(chan int)
	for i := 0; i < 10; i++ {
		go f(ctx, ch)
	}
	cancel()
	http.HandleFunc("/", GetGoroutineNum)
	http.ListenAndServe(":3000", nil)
}

func GetGoroutineNum(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "text/plain")
	p := pprof.Lookup("goroutine")
	p.WriteTo(w, 1)
}

```
