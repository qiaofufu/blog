title: Go 并发的安全退出
author: Qiao
date: 2022-10-16 15:07:53
tags: [golang,goroutine]
categories: [golang]
excerpt: [goroutine goroutine 安全退出方案]
---
# Go 并发下的安全退出

> `main` 函数退出时,并不会等待所有`goroutine`结束后退出,此时可能会导致一些问题

我们可以利用`sync`包下的`WaitGroup`来控制并发安全退出

```go

package main

import (
	"fmt"
	"sync"
	"time"
)

func worker(cancel chan bool, wg *sync.WaitGroup) {
	for {
		select {
		default:
			fmt.Println("hello") // 正常工作
		case <-cancel:
			fmt.Println("exit") // 退出
			wg.Done()
			return
		}
	}
}

func main() {
	cancel := make(chan bool)
	var wg sync.WaitGroup
	for i := 0; i < 10; i++ {
		wg.Add(1)
		go worker(cancel, &wg)
	}

	time.Sleep(time.Second)
	close(cancel)
	wg.Wait()
}


```
