title: Go Context
author: Qiao
date: 2022-11-09 20:35:58
tags:
---
# context

## 使用目的

>  context包的使用目的是,在goroutine树中用于同步信号减少资源浪费(父groutine发送关闭信号,子groutine同时关闭)

## context.Context

为了学习context包,我们有必要认识一下他的核心组成接口

```go
type Context interface {
    Deadline() (deadline time.Time, ok bool) 
    Done() <-chan struct{}
    Err() error
    Value(key any) any 
}
```

- `Deadline()` 返回context的截至时间,也就是停止工作的时间
- `Done()`返回一个channel, 这个channel会在工作完成时或被取消时关闭
- `Err()`当Done()返回的channel被关闭时,返回关闭的原因,超时返回`DeadlineExceeded`,被取消返回`Canceled`

- `Value()`返回这个`context`的`key`对应的值

## context.WithCancel

```go
func work(ctx context.Context) {
	select {
	case <-ctx.Done():
		fmt.Println("work done")
	case <-time.After(time.Second):
		fmt.Println("work end")
	}
}

func main() {
	ctx, cancel := context.WithCancel(context.Background())
	go work(ctx)
	time.Sleep(time.Millisecond * 500)
	cancel()
	select {
	case <-ctx.Done():
		fmt.Println("context done")
	}
	time.Sleep(time.Second)
}

-------
> context done
> work done
```

- `context.WithCancel()`返回一个子`context`和一个取消这个`context`的`cancel`函数
- 调用`cancel()`不仅会取消这个`context`还会取消这个`context`的所有子`context`

## context.WithDeadline

```go

----------------------
func work(ctx context.Context) {
	select {
	case <-ctx.Done():
		fmt.Println("work done")
	case <-time.After(time.Second):
		fmt.Println("work end")
	}
}

func main() {
	ctx, cancel := context.WithDeadline(context.Background(), time.Now().Add(time.Second))
	go work(ctx)
	time.Sleep(time.Second * 2)
	cancel()
}
```

- `context.WithDeadline()`返回一个`context`和取消这个`context`的函数,同时设置一个超时时间
- 当超时时`Done`被关闭,同时`Err`返回`DeadlineExceeded`

- 当调用`cancel`时,`Done`被关闭,同时`Err`返回`Canceled`

## context.WithTimeout

```go
// 函数原型
func WithTimeout(parent Context, timeout time.Duration) (Context, CancelFunc) {
	return WithDeadline(parent, time.Now().Add(timeout))
}
-------------------------------------
WithDeadline的上层封装
```

## context.WithValue

```go
// 函数签名
WithValue(parent Context, key, val any) Context
-------------------------
func main() {
	ctx := context.WithValue(context.Background(), 1, 2)
	val := ctx.Value(1)
	println(val.(int))
}
----
> 2
```

- 尽量不使用这种方式