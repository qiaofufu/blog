title: Go Map
author: Qiao
tags:
  - go
  - map
categories:
  - go
excerpt: go map
date: 2022-09-19 09:55:00
---
# Go map

> map /mæp/

map是go中哈希表的实现,属于内置类型

# map声明

## 格式

```
map[KeyType]ValueType
```

> - KeyType必须是可比较的类型
>
> - ValueType可以是任何类型,包括map



map是引用类型,类似于指针或者slice, 所以一个`map`的值可能为`nil`

**警告**: 一个值为`nil`的`map`并没有指向一个初始化的`map`,当你读的时候它,像一个空的`map`,但当你写的时候将导致`runtime panic`

# map初始化

初始化`map`需要使用内置函数`make`或者`map字面量`

```go
var m map[string]int
m = make(map[string]int)

m2 := map[string]int{} // 与上面的等效
```



# map用法

## 设置key-value

```go
m["route"] = 66 // 设置 键 "route" 值 66
```

## 根据key获取value

```go
i := m["route"] // 获取存储在键"route"下的值
// 如果key不存在,将会返回value类型的零值
i := m["qff"]
// i == 0 => true
// 返回二值确定key是否存在
i, ok := m["route"] // ok为true则key存在, 反之不存在
```

## 获取map中key-value的个数

```go
n := len(m)
```

## 删除map中的key-value

```go
delete(m, "route") // delete没有任何返回值, 如果键不存在,将不会做任何事情
```

## 遍历map中的元素

```go
for key, value := range m {
    fmt.Println("Key: ", key, " Value: ", value)
}
```

## 初始化map

```go
m := map[string]int {
    "stg": 1143,
    "er" : 2001,
    "rtat": 5959,
}
```

## Key的Type

除了`slice`, `map`,`function`都可以用作`map`的`key`

# map并发安全

map不是并发安全的,map不是并发安全的,map不是并发安全的

## 通用方法

### sync.RWMutex

```go
var couter = struct {
    sync.RWMutex
    m map[string]int
} {m: make(map[string]int)}

// read
couter.RLock()
n := counter.m["some_key"]
couter.RUnlock()

// write
counter.Lock()
counter.m["some_key"] ++
counter.Unlock()
```

# map 迭代

map并不保证每次迭代时顺序时一致的,当你需要一个稳定的迭代顺序时,需要维护一个key的数据结构

```go
var m map[int]string
var keys []int

for k := range m {
    keys = append(keys, k)
}

sort.Ints(keys)
for _, k := range keys {
    fmt.Println("Keys: ", k, " Value: ", m[k])
}
```

[go map]: https://blog.golang.org/maps	"官方文档"