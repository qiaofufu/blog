title: 一致性hash
author: John Doe
tags:
  - 缓存
  - 负载均衡
categories:
  - 缓存
  - 负载均衡
date: 2023-08-23 19:15:00
---
# 一致性Hash

## 情景引入

> 在我们的项目中如果需要用到负载均衡，那么常规的做法就是Round Robin（轮询），加权轮询等，还有一种做法就是hash，通过对key进行hash操作，然后对hash值进行取模操作，选择最终服务节点，这样将某个区间的请求负载到某一个固定的节点（数据分片式分布式数据库也可通过hash找到数据的存储节点）. 但这一过程会产生一些问题。。。

## 普通的Hash

> 首先我们来看普通的hash会出现什么问题

![图片](https://github.com/qiaofufu/draw_io/raw/master/%E4%B8%80%E8%87%B4%E6%80%A7hash-%E6%99%AE%E9%80%9Ahash.drawio.svg)

- 我们首先假设有0~5六个请求
- 首先0，3 取模 3 得到 0 所以被负载到 1 号节点
- 其次1，4 取模 3 得到 1 所以被负载到 2 号节点
- 最后2，5 取模 3 得到 2 所以被负载到 3 号节点

目前看起来一切皆好， 但如果我们横向扩展了一个节点呢？

![图片2](https://github.com/qiaofufu/draw_io/raw/master/%E4%B8%80%E8%87%B4%E6%80%A7hash-%E6%99%AE%E9%80%9Ahash-2.drawio.svg)

我们可以通过上图看到， 原本的3，4，5的哈希结果都出现了偏差，这就是普通的hash会出现的问题

> 当我们横向扩展节点时，原本的hash映射的结果会出现偏差，使得扩展前后的映射结果不一致

怎么结果横向扩展所造成的问题呢，一种比较直观的做法是在横向扩展节点时， 将节点内的所有数据重新hash，建立新的映射， 但我们也可以很直接的发现这种操作的问题: 需要移动大量的数据，这显然不是一个很好的解决办法， 那么有没有什么操作可以减少移动数据的数量呢？

## 一致性Hash

如需解决上述移动次数过多的问题，我们可以通过一致性Hash（分布式Hash）来替换掉普通Hash

### 什么是一致性Hash

> 一致性Hash是指将节点和数据都映射到一个hash环上（取模$2^{32}-1$）, 每次查找指定数据在哪个节点，就通过当前数据的hash值，在hash环上顺时针找到第一个节点，就是数据存放的节点，这样就可以保证当我们横向扩展节点时，大部分数据还是处于原来位置，仅需移动当前新节点到它之前节点间的数据即可

![iamge](https://github.com/qiaofufu/draw_io/raw/master/%E4%B8%80%E8%87%B4%E6%80%A7hash-01.drawio.svg)

- 当我们新添加节点 `Node4` 时， 仅需移动 `Node3` 到 `Node4` 之间的数据即可

但是呢。话又说回来，我们是对$2^{32}-1$取模， 当我们节点数量少的时候，节点与节点之间的间隔就会不够``均匀``,会造成有的节点被大量的访问， 有的节点访问很少

![image2](https://github.com/qiaofufu/draw_io/raw/master/%E4%B8%80%E8%87%B4%E6%80%A7hash-02.drawio.svg)

- 上图大量节点在`Node4` 与 `Node1`之间，会导致`Node1`的负载很大

如何解决上述问题呢？ 我们可以通过引入大量的虚拟节点来将这个间隔变小，这样就可以解决分布不均匀的问题了

![image](https://github.com/qiaofufu/draw_io/raw/master/%E4%B8%80%E8%87%B4%E6%80%A7hash-03.drawio.svg)

## golang 一致性hash 实现

```go
package consistenthash

import (
	"hash/crc32"
	"sort"
	"strconv"
)

type hashFunc func([]byte) uint32

type ConsistentHash struct {
	keys     []int          // 所有节点哈希值
	hashFunc hashFunc       // 哈希函数
	replicas int            // 虚拟节点个数
	hashMap  map[int]string // 虚拟节点到真实节点的映射
}

func New() ConsistentHash {
	return ConsistentHash{
		hashFunc: crc32.ChecksumIEEE,
		replicas: 150,
		hashMap: make(map[int]string),
	}
}

func (c *ConsistentHash) AddNode(key string) {
	for i := 0; i < c.replicas; i++ {
		hashVal := c.hashFunc([]byte(strconv.Itoa(i) + key))
		c.keys = append(c.keys, int(hashVal))
		c.hashMap[int(hashVal)] = key
	}
	sort.Ints(c.keys)
}

func (c *ConsistentHash) GetNode(key string) string {
	hashVal := c.hashFunc([]byte(key))
	idx := sort.Search(len(c.keys), func(i int) bool {
		return c.keys[i] >= int(hashVal)
	})
	return c.hashMap[idx]
}


```

## 参考文章
[什么是一致性哈希？ | 小林coding](https://www.xiaolincoding.com/os/8_network_system/hash.html)