title: code tips 之 sync.WaitGroup妙用
author: John Doe
tags:
  - tips
categories:
  - tips
date: 2023-08-22 22:31:00
---
# 利用WaitGroup并发访问DB

## 适用场景

> 在之前写的项目中，当需要查询多个数据库/数据表时，不论他们之间没有先后关系的要求，都是统一一个接着一个去访问db，这种方式对于先后次序无关的查询或者操作来说效率太低，我们可以考虑并发的去访问数据库来进行优化

## Code

```go
func GetUserInfo(query_id int) (model.User, error) {
	var (
		errCh = make(chan error, 2)
		wg = sync.WaitGroup{}
		user model.User
		friends []model.User
		err error
	)
	
	wg.Add(2)

	go func() {
		user, err = db.QueryUserInfo(query_id)
		if err != nil {
			errCh <- err
		}
		wg.Done()
	}()


	go func() {
		friends, err = db.QueryUserFriends(query_id)
		if err != nil {
			errCh <- err
		}
		wg.Done()
	}()

	wg.Wait()
	select {
	case err := <- errCh:
		return model.User{}, err
	default:
	}

	user.Friends = friends
	return user, nil
}
```