title: Go Slice
author: Qiao
tags:
  - go
  - slice
categories:
  - go
date: 2022-09-19 09:55:00
excerpt: go slice 
---
# Go Slice

> Slice /slaɪs/

Slice 底层是Go中的数组



## 创建Slice的方法

### 方法一

```go
// 与数组的区别是, 没有元素数量
letter := []string{"ab", "cd", "ef"} // => slice
word := [2]string{"ab", "cd"} // => arrary
```

### 方法二

```go
// 通过内置函数make创建
// 函数签名,
func make([]T, len, cap) []T
// 使用
letter := make([]string, 10, 10)
// cap 是可选参数, 不传时, 默认与len一样长
// 上面代码更简洁的写法
letter := make([]string, 10)
```

### 方法三

> slicing 将一个slice或者array切为slice格式为: [start:end], `start`省略时默认为`0`, `end`省略时默认为`length`

```go
// 通过slicing从array中生成
arr := [3]uint{32, 64, 128}
sliceOne := arr[0:2] // sliceOne: [32, 64]
// 通过slicing从slice中生成
s := []uint{32, 64, 128, 256}
sliceTwo := s[0:3] // sliceTwo: [32, 64, 128]
```



## Slice length 和 capacity

`length`是Slice中元素的个数, `capacity`是Slice内部`arrary`的大小.

通过`go`内置函数`len()`和`cap()`可以获取Slice的`length`和`capacity`

> tips: 
>
> ​	当slice 为`nil`时, slice的`length`和`capacity`为`0

## Slice内部

Slice内部是一个指向底层数组的指针,以及一个slice已有元素大小`length`和从当前指针开始底层数组大小`capacity`

**警告**: 通过slicing操作生成的slice,不会生成新的数组,而是直接生成一个指向当前位置指针,这意味着当你修改slicing生成的slice是,其底层数组也会改变,同时也不能访问当前指针之前的数组

### 增长capacity

与其他语言的动态数组一致,首先会生成一个新的更大的slice,然后将当前slice的内容拷贝过去

```go
t := make([]byte, len(s), (cap(s)+1)*2) // +1 in case cap(s) == 0
for i := range s {
        t[i] = s[i]
}
// 上面的循环可以用内置函数cope(dis, src []T) int替换
cope(t, s)
s = t
```

## append

给切片增加一个元素,必要时增长其capacity

```go
func AppendByte(slice []byte, data ...byte) []byte {
    m := len(slice)
    n := m + len(data)
    if n > cap(slice) { // if necessary, reallocate
        // allocate double what's needed, for future growth.
        newSlice := make([]byte, (n+1)*2)
        copy(newSlice, slice)
        slice = newSlice
    }
    slice = slice[0:n]
    copy(slice[m:n], data)
    return slice
}
```

不需要详细控制时,可以使用内置函数`append`

```go
// 函数签名
func append(s []T, x ...T) []T 
// 用法
s := []int{1, 2, 3}
s = append(s, 4)
// 将一个切片添加到另外一个切片
s1 := []int{1, 2, 3}
s2 := []int{4, 5, 6}
s1 = append(s1, s2...) // 使用...展开一个slice到参数列表
```

[^go slice]: [Go Slices: usage and internals - The Go Programming Language](https://go.dev/blog/slices-intro)