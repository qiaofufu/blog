title: Go pprof 性能分析
author: Qiao
date: 2022-10-16 22:41:45
tags:
---
# Go pprof

> pprof 是 go 标准库中的性能分析工具,可以帮助开发者分析性能

## 支持分析的数据类型



pprof支持分析如下常用数据

- CPU Profiling CPU分析
- Memory Profiling 内存分析
- Block Profiling 阻塞分析
- Mutex Profiling 互斥锁分析

## 工具型pprof

> 主要使用`runtime/pprof`库,将画像数据写入文件

```go
package main 

import (
	"fmt"
    "routine/pprof"
)

func myFunc() {
    for i := 0; i < 1000; i++ {
        fmt.Println(i)
    }
}

func main() {
    f, err := os.Create(',/CPUProfile')
    if err != nil {
        return 
    }
    defer f.close()
    
    pprof.StartCPUProfile(f)
	
    myFunc()
    
    pprof.StopCPUProfile()
}
```

## 服务型pprof

> 主要使用`net/htpp/pprof`库,将画像数据通过`http`请求

```go
package main

import (
	"fmt"
	"net/http"
	_ "net/http/pprof" // 这里匿名导入
)

func sayHello(w http.ResponseWriter, r *http.Request) {
	r.ParseForm()
	fmt.Println(r.Form)
	for i := 0; i < 100; i++ {
		fmt.Println(i)
	}
	fmt.Fprintln(w, "hello")
}

func main() {
	http.HandleFunc("/", sayHello)
	err := http.ListenAndServe(":3000", nil)
	if err != nil {
		fmt.Println(err)
	}
}
```

## 分析pprof导出文件

例如`CPUProfile`

```bash
> go tool pprof ./CPUProfile
Type: cpu
Time: Oct 16, 2022 at 9:53pm (CST)
Duration: 212.65ms, Total samples = 10ms ( 4.70%)
Entering interactive mode (type "help" for commands, "o" for options)
> (pprof) top 20 #展示前20个占用cpu时长
Showing nodes accounting for 10ms, 100% of 10ms total
      flat  flat%   sum%        cum   cum%
      10ms   100%   100%       10ms   100%  runtime.cgocall
         0     0%   100%       10ms   100%  fmt.Fprintln
         0     0%   100%       10ms   100%  fmt.Println (inline)
         0     0%   100%       10ms   100%  internal/poll.(*FD).Write
         0     0%   100%       10ms   100%  internal/poll.(*FD).writeConsole
         0     0%   100%       10ms   100%  main.main
         0     0%   100%       10ms   100%  main.myFunc
         0     0%   100%       10ms   100%  os.(*File).Write
         0     0%   100%       10ms   100%  os.(*File).write (inline)
         0     0%   100%       10ms   100%  runtime.main
         0     0%   100%       10ms   100%  syscall.Syscall6
         0     0%   100%       10ms   100%  syscall.SyscallN
         0     0%   100%       10ms   100%  syscall.WriteConsole
> (pprof) list main.main # 展示main.main函数的执行时间
Total: 10ms
ROUTINE ======================== main.main in D:\Project\Goland\Test\main_server.go
         0       10ms (flat, cum)   100% of Total
         .          .     19:   }
         .          .     20:   defer f.Close()
         .          .     21:
         .          .     22:   pprof.StartCPUProfile(f)
         .          .     23:
         .       10ms     24:   myFunc()
         .          .     25:
         .          .     26:   pprof.StopCPUProfile()
         .          .     27:}
```

> 通过这种操作,可以查看热点代码,进行调优
