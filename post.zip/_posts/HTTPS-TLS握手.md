title: HTTPS-TLS握手
author: Qiao
date: 2023-09-14 14:00:36
tags:
---
# HTTPS TLS 握手解析

## 第一次握手

- Client 发送TLS版本号, 支持的加密算法套件, Client 随机值(Client Hello)

## 第二次握手

- Server 发送选择的加密算法, Server 随机值 (Server Hello)
- Server 发送CA证书 (Server Certificate)
- Server 发送Hello Done (Server Hello Done)

## 第三次握手

- Client 用CA证书中的非对称公钥加密pre-master随机值, 并发送给Server(Client Key Exchange)
- Client 告诉 server 接下来用对称密钥(client 随机数, server 随机数, pre-master)发送消息(Change Cipher Spec)
- Client 发送本次握手的摘要信息,并用生成的对称密钥加密, 发送给server

## 第四次握手

- server 用非对称私钥解密pre-master
- server 告诉 client 接下来用对称密钥(client 随机数, server 随机数, pre-master)发送信息
- server 用对称加密本次握手的摘要信息, 发送给Client
