title: Go Mutex
author: Qiao
tags: []
categories: []
date: 2022-11-10 21:42:00
---
# Go Mutex

## 基本锁

### Mutex

> 基本的互斥锁

#### 操作



```go
import "sync"

func main() {
    m := sync.Mutex{}
    // 加锁
    m.Lock()
    // 解锁
    m.Unlock()
}
```

#### 原型

```go
type Mutex struct {
    state int32 // 锁的状态, 未上锁时时0
	sema  uint32
}
|--------------sema-----------------|
|  waitCount  |starving|woken|locked|
```

`Mutex.sema`的不同位表示了不同的状态

- `locked`-表示互斥锁的锁定状态
- `woken`-表示互斥锁从正常模式被唤醒
- `starving`-表示互斥锁处于饥饿状态
- `waitCount`-表示当前互斥锁上等待`Groutine`的数量

#### 饥饿模式与普通模式

>  饥饿模式是在`go 1.9`引入的优化,引入的目的是为了保证互斥锁的公平性

###### 正常模式

- 在正常模式中锁的等待者按照先进先出的方式获取锁.
- 刚被唤醒的`Goroutine`与新创建的`Goroutine`相比大概率获得不到锁
- 一旦`Goroutine`超过`1ms`没有获得锁,他就会切换到饥饿模式
- 会进入自旋状态

###### 饥饿模式

- 在饥饿模式中互斥锁会直接交给等待队列最前面的`Goroutine`.
- 新的`Goroutine`在该状态下不会获得锁,也不会进入`自旋`,而是直接排到等待队列的队尾
- 如果一个`Goroutine`获得了锁,并且它在等待队列的末尾或它等待的时间少于`1ms`,该互斥锁会切换回正常模式
- 不会进入自旋状态

###### 比较

正常模式有更好的性能,但会导致高尾延时

饥饿模式保证公平性,但性能有所降低

### RWMutex

> RWMutex 是粒度更细的读写锁,它支持同时读,读写互斥,写写互斥

#### 操作

```go
import "sync"

func main() {
    rw := sync.RWMutex{}
    // 加读锁
    rw.RLock()
    // 解读锁
    rw.RUnlock()
    // 加写锁
    rw.Lock()
    // 解锁
    rw.Unlock()
}
```

### WaitGroup

> WaitGroup 可以等待一组`Goroutine`返回, 常用于发送HTTP, RPC请求

#### 操作

```go
import "sync"

func main() {
	wg := sync.WaitGroup{}
	// 添加
	wg.Add(10)
	for i := 0; i < 10; i++ {
		go work(&wg, i+1)
	}
	// 等待所有Goroutine完成
	wg.Wait()
	fmt.Println("all groutine end")
}

func work(wg *sync.WaitGroup, no int) {
	time.Sleep(time.Second)
	fmt.Println(no, " end.")
	// 通知一个Goroutine已经完成
	wg.Done()
}
```



### Once

> Once 可以保证函数只会被执行一次

#### 操作

```go
func main() {
	on := sync.Once{}
	on.Do(work) // 第一次会执行,即使panic也只会执行一次
	on.Do(work) // 不会执行
}

func work() {
	fmt.Println("working")
}
```



### Cond

> Cond 条件变量, 可以同时唤醒满足条件的`Goroutine`

#### 使用

```go
var state int64

func main() {
	c := sync.NewCond(&sync.Mutex{}) // 新建Cond需要传一个互斥锁指针进去
	for i := 0; i < 10; i++ {
		go work(c) 
	}
	time.Sleep(time.Second)
	go broadCase(c)

	ch := make(chan os.Signal, 1)
	signal.Notify(ch, os.Interrupt)
	<-ch
}

func broadCase(c *sync.Cond) {
	c.L.Lock() // 必须加锁
	atomic.StoreInt64(&state, 1)
	c.Broadcast() // 唤醒所有等待的Goroutine
    // c.Signal() 唤醒第一个等待的Goroutine
	c.L.Unlock()
}

func work(c *sync.Cond) {
	c.L.Lock() // 必须加锁
	for atomic.LoadInt64(&state) != 1 {
		c.Wait() // 条件不满足陷入等待
	}
	fmt.Println("working")
	c.L.Unlock()
}
```

