title: Go goroutine 顺序一致性
author: Qiao
tags:
  - golang
  - goroutine
categories:
  - golang
excerpt:
  - goroutine 顺序一致性
date: 2022-10-16 17:17:00
---
# goroutine 不满足顺序一致性内存模型

> goroutine 之间是不满足顺序一致性内存模型的

```go
package main

var msg string
var done bool

func setup() {
	msg = "hello, world"
	done = true
}

func main() {
	go setup()
	for !done {
	}
	println(msg)
}

```

例如,在上述代码中, 我们的本意是用一个`goroutine A` 来改变全局变量`done`, 用另外一个`goroutine`B 监听`done`, 当`done`变化时,B做相应的操作

But 这样做有一定的风险, 因为go并不保证不同goroutine之间满足顺序一致性内存模型

在一个`goroutine`中, 两个没有关联的语句之间,他们执行顺序可能会被编译器或CPU更改

例如

```go
func setup() {
	msg = "hello, world"
	done = true
}
// 可能会被编译器优化成
func setup() {
    done = true
	msg = "hello, world"
}
```

这将会导致 `main`中的`msg`还没有赋值,就被输出

## 解决方案

> 在不同goroutine之间添加同步语句

例如

```go
package main

var msg string
var done chan bool

func setup() {
	msg = "hello, world"
	done <- true
}

func main() {
	go setup()
	<- done	
	println(msg)
}

```